// Fill out your copyright notice in the Description page of Project Settings.


#include "Interaction/EnemyInterface.h"

// Add default functionality here for any IEnemyInterface functions that are not pure virtual.
